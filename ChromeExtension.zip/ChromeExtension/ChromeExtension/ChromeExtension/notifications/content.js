var msgGoBtn = "Click Go button";
var msgGetResult = "HTTP response is returned";
var msgGetMailContent = "Get mail content";
var flagBtnClicked = false;
var specialQ = new Array("EMEA", "AMER", "DS IMS");
var mailContent = "";

deadline_date = 1;
deadline_time = "08:20";

// 其他譌ｶ区的16点之前的要管，(蛻ｫ的譌ｶ区霑㈱咩I不要管)
// APJ譌ｶ区第二天8：20之前霑㈱咩I要管 (霑㈱咩I要管）
function getDates() {
	var now = new Date();
	var deadlineOtherTimeZone = new Date(now.getFullYear(), now.getMonth(), now.getDate(), "16");
	var deadlineAPJ = new Date(now.getFullYear(), now.getMonth(), now.getDate()+parseInt(deadline_date), deadline_time.substring(0,2), deadline_time.substring(3,5));
	var dates = {now: now, deadlineOtherTimeZone: deadlineOtherTimeZone, deadlineAPJ: deadlineAPJ};
	return dates;
}

function getInnerDoc2() {
	var CRMApplicationFrame = document.getElementById('CRMApplicationFrame');
	var innerDoc1 = (CRMApplicationFrame.contentDocument) ? CRMApplicationFrame.contentDocument : CRMApplicationFrame.contentWindow.document;
	
	var WorkAreaFrame1 = innerDoc1.getElementById('WorkAreaFrame1');
	var innerDoc2 = (WorkAreaFrame1.contentDocument) ? WorkAreaFrame1.contentDocument : WorkAreaFrame1.contentWindow.document;
	return innerDoc2;
}

 function getColomIndex(incidentTableHead) {
	var columnIndexs = {priority: 0, irtTime: 0, number: 0, description: 0, irtLight: 0, component: 0, country: 0, contract: 0, language: 0};
	for(var i = 0; i < incidentTableHead.childNodes.length; i++) {
		if(incidentTableHead.childNodes[i].childNodes[0].innerText.indexOf("Priority") >= 0) {
			columnIndexs.priority = i;
		}
		else if(incidentTableHead.childNodes[i].childNodes[0].innerText.indexOf("IRT Planned End Date") >= 0) {
			columnIndexs.irtTime = i;
		}
		else if(incidentTableHead.childNodes[i].childNodes[0].innerText.indexOf("Incident Number") >= 0) {
			columnIndexs.number = i;
		}
		else if(incidentTableHead.childNodes[i].childNodes[0].innerText.indexOf("Description") >= 0) {
			columnIndexs.description = i;
		}
		else if(incidentTableHead.childNodes[i].childNodes[0].innerText.indexOf("IRT Traffic Light") >= 0) {
			columnIndexs.irtLight = i;
		}
		else if(incidentTableHead.childNodes[i].childNodes[0].innerText.indexOf("Component") >= 0) {
			columnIndexs.component = i;
		}
		else if(incidentTableHead.childNodes[i].childNodes[0].innerText.indexOf("Customer Country") >= 0) {
			columnIndexs.country = i;
		}
		else if(incidentTableHead.childNodes[i].childNodes[0].innerText.indexOf("Contract Type") >= 0) {
			columnIndexs.contract = i;
		}
		else if(incidentTableHead.childNodes[i].childNodes[0].innerText.indexOf("Language") >= 0) {
			columnIndexs.language = i;
		}
	}
	return columnIndexs;
 }
 
 function getResultIRT(incidentTableBody, columnIndexs, flagSpecialQ) {
	var result = {content: "", count: 0};
	for(var i = 0; i < incidentTableBody.length; i++) {
		var lightIRT = incidentTableBody[i].childNodes[columnIndexs.irtLight].innerText; 
		if(lightIRT < "OK") {
			var priorityStr = incidentTableBody[i].childNodes[columnIndexs.priority].innerText;
			var timeStr = incidentTableBody[i].childNodes[columnIndexs.irtTime].innerText;
			var IRT = new Date(timeStr.substring(6,10), timeStr.substring(3,5), timeStr.substring(0,2), timeStr.substring(11,13), timeStr.substring(14,16));
			IRT.setMonth(IRT.getMonth()-1);
			if(IRT.toString() == "Invalid Date") {
				result.content = "!!!Invalid Date: " + timeStr + "---" + IRT.toString();
				result.count = 1;
				break;
			}

			var flag = false;
			if(priorityStr >= "Very high") {
				flag = true;
			} 
			else {
				var dates = getDates();
				if(flagSpecialQ) { // Other time zone Q
					if(IRT <= dates.deadlineOtherTimeZone && IRT >= dates.now) { // we do not care if other time zone q IRT light is red.
						flag = true;
						
					}
				} else { // APJ Q
					if(IRT <= dates.deadlineAPJ) {	
						flag = true;
					}
				}
			}
			
			if(flag) {			
				 var incidentNo = incidentTableBody[i].childNodes[columnIndexs.number].innerText;
				 var incidentComponent = incidentTableBody[i].childNodes[columnIndexs.component].innerText;
				 var incidentDes = incidentTableBody[i].childNodes[columnIndexs.description].innerText;
				 var incidentCountry = incidentTableBody[i].childNodes[columnIndexs.country].innerText;
				 var incidentContract = incidentTableBody[i].childNodes[columnIndexs.contract].innerText;
				 var incidentLanguage = incidentTableBody[i].childNodes[columnIndexs.language].innerText;
				 
				 timeStr = timeStr[timeStr.length-1] == '\n' ? timeStr.slice(0, timeStr.length-1) : timeStr;
				 incidentComponent = incidentComponent[incidentComponent.length-1] == '\n' ? incidentComponent.slice(0, incidentComponent.length-1) : incidentComponent;
				 incidentNo = incidentNo[incidentNo.length-1] == '\n' ? incidentNo.slice(0, incidentNo.length-1) : incidentNo;
				 incidentDes = incidentDes[incidentDes.length-1] == '\n' ? incidentDes.slice(0, incidentDes.length-1) : incidentDes;
				 incidentCountry = incidentCountry[incidentCountry.length-1] == '\n' ? incidentCountry.slice(0, incidentCountry.length-1) : incidentCountry;
				 incidentContract = incidentContract[incidentContract.length-1] == '\n' ? incidentContract.slice(0, incidentContract.length-1) : incidentContract;
				 incidentLanguage = incidentLanguage[incidentLanguage.length-1] == '\n' ? incidentLanguage.slice(0, incidentLanguage.length-1) : incidentLanguage;
				 
				 result.content += "|" + timeStr + "|-|" + incidentCountry + "|-|" + incidentComponent + "|-|" + incidentContract + "|-|" + incidentLanguage + "|-|" + incidentNo + "|-|" + incidentDes + "|" + "\r\n";
				 result.count++;

			}
		}
	}
	return result;
 }
 
function HandlerGetResult(sendResponse, request) {
	try {
		if(flagBtnClicked) {
			var innerDoc2 = getInnerDoc2();
			var queueName = innerDoc2.getElementsByClassName("th-if th-if-icon")[0].value;
			var flagSpecialQ = false;
			for(var i = 0; i < specialQ.length; i++) {
				if(queueName.indexOf(specialQ[i]) >= 0) {
					flagSpecialQ = true;
					break;
				}
			}
			var resultLabel = innerDoc2.getElementsByClassName("th-sf-rs-title-caption")[0];
			
			var incidentTableHead = innerDoc2.getElementsByClassName("th-clr-thead")[0].childNodes[1];
			var columnIndexs = getColomIndex(incidentTableHead);
			
			var incidentTableBody = innerDoc2.getElementsByClassName("th-clr-tbody")[0].children;
			result = getResultIRT(incidentTableBody, columnIndexs, flagSpecialQ);
			
			if(result.count > 0) {
				mailContent = "Queue Name: " + queueName + "\n" + "There are " + result.count + " incident IRT light(s) need to be stopped.\n" + result.content;
				//mailContent += request.xhrResponse.url;
				resultLabel.innerText += "\n" + mailContent;
				sendResponse({msg: mailContent, xhrResponse: request.xhrResponse});
			}
			else {
				mailContent = "";
			}
			flagBtnClicked = false;
		}
	} catch(error) {
		sendResponse({msg: "Get result error! (" + error + ") " + request.xhrResponse.url + "\r\n", xhrResponse: request.xhrResponse});
	}
}

function HandlerGoBtn(sendResponse, request) {
	try{
		var innerDoc2 = getInnerDoc2();
		var goBtn = null;
		var elements = innerDoc2.getElementsByClassName("th-bt-b");
		for (var i = 0; i < elements.length; i++) { 
			if(elements[i].innerHTML == "Go") {
				goBtn = elements[i].parentNode.parentNode;
				break;
			}
		}
		
		goBtn.click();
		flagBtnClicked = true;
		deadline_date = request.deadline_date;
		deadline_time = request.deadline_time;
		sendResponse({msg: msgGoBtn + flagBtnClicked, tabId: request.tabId});
	} catch(error) {
		flagBtnClicked = false;
		sendResponse({msg: "!!!Warning: The BCP Tab is loaded incorrectly! (Message: " + error + ")\r\n You can wait for the tab being loaded or \r\nrefresh(press F5) this tab to reload this tab. \r\nclick here to display the tab!", tabId: request.tabId});
	}
}

chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
	if (request.msg == msgGetResult) {
		HandlerGetResult(sendResponse, request);
	}
	else if(request.msg == msgGoBtn) {
		HandlerGoBtn(sendResponse, request);
	}  
	else if(request.msg == msgGetMailContent) {
		sendResponse({mailContent: mailContent});
	} 
});