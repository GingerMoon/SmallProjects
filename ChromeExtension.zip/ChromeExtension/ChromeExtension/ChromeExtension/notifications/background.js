var msgGoBtn = "Click Go button";
var msgGetResult = "HTTP response is returned";
var msgGetMailContent = "Get mail content";

var mailContent = "Hi all, \r\n\r\n";

function executeMailto(tab_id, mailto, subject, body) {
  var action_url = "mailto:" + mailto + "?";
  
  if (subject.length > 0)
	action_url += "subject=" + encodeURIComponent(subject) + "&";

  if (body.length > 0) {
    action_url += "body=" + encodeURIComponent(body);
  }

    chrome.tabs.update(tab_id, { url: action_url });
}

var notificationId2tabId = new Array();
function deleteTabId(notificationId) {
	for(var index in notificationId2tabId) {
		if(notificationId2tabId[index][0] == notificationId) {
			var result = notificationId2tabId[index][1];
			notificationId2tabId.splice(index, 1);
			return result;
		}
	}
	return null;
}

function show(warningContent, tabId) {
	var time = /(..)(:..)/.exec(new Date());     // The prettyprinted time.
	var hour = time[1] % 12 || 12;               // The prettyprinted hour.
	var period = time[1] < 12 ? 'a.m.' : 'p.m.'; // The period of the day.

	chrome.notifications.create("", {type: "basic",   title: hour + time[2] + ' ' + period, iconUrl: "logo_sap.png", message: warningContent, isClickable: true}, function(notificationId){
		notificationId2tabId.push([notificationId, tabId]);
		chrome.notifications.onClicked.addListener(function(notificationId) {
			chrome.windows.getCurrent(function(window) {
				chrome.windows.update(window.id, {focused:true}, function(window){
					var tabId = deleteTabId(notificationId);
					chrome.tabs.update(tabId, {active: true, highlighted: true});
					chrome.notifications.clear(notificationId, function(wasCleared){
					})
				})
			});
		});
	});
}

chrome.webRequest.onCompleted.addListener(
	function(details) {
		if (JSON.parse(localStorage.isActivated)) {
			chrome.tabs.sendMessage(details.tabId, {msg: msgGetResult, xhrResponse: details}, function(response) {
				try {
					show(response.msg, response.xhrResponse.tabId);
				} catch (error){
					console.log("!!!" + error);
				}
			});		
		}
		
    },
	// filters
	{
	urls: [
	  "https://support.wdf.sap.corp/*"
	]
	},
	null
);

// Conditionally initialize the options.
if (!localStorage.isInitialized) {
  localStorage.isActivated = false;   // The display activation.
  localStorage.frequency = 1;        // The display frequency, in minutes.
  localStorage.isInitialized = true; // The option initialization.
  localStorage.mailto = "Email Addresses";
  localStorage.deadline_time = "08:20";
  localStorage.deadline_date = 1;
}

if (window.Notification) {
  if (JSON.parse(localStorage.isActivated)) { show("Monitor begin!"); }

  var interval = 0; 

  setInterval(function() {
	
    interval++;

    if (
      JSON.parse(localStorage.isActivated) &&
        localStorage.frequency <= interval
    ) {
		chrome.tabs.query({url: "https://support.wdf.sap.corp/*"}, function(tabs) {
			for(var i = 0; i < tabs.length; i++) {		
				chrome.tabs.sendMessage(tabs[i].id, 
											{msg: msgGoBtn, tabId: tabs[i].id, deadline_time: localStorage.deadline_time, deadline_date: localStorage.deadline_date}, 
											function(response) {
					if(response.msg.indexOf("Warning") >= 0) {
						show(response.msg, response.tabId);
					}
				});
			}
		});
		interval = 0;
    }
  }, 60000);
}

chrome.runtime.onConnect.addListener(function(port) {
  console.assert(port.name == "email");
  port.onMessage.addListener(function(msg) {
	  if(msg.action == "SendEmail") {
		chrome.tabs.query({url: "https://support.wdf.sap.corp/*"}, function(tabs) {
			executeMailto(tabs[0].id, localStorage.mailto, "Queue", mailContent);
		});
	  }
	  else if(msg.action == "GetContent") {
		mailContent = "Hi all, \r\n\r\n";
		chrome.tabs.query({url: "https://support.wdf.sap.corp/*"}, function(tabs) {
			for(var i = 0; i < tabs.length; i++) {		
				chrome.tabs.sendMessage(tabs[i].id, {msg: msgGetMailContent, tabId: tabs[i].id}, function(response) {
					mailContent += response.mailContent + "\r\n";
				});
			}
		});
	  }
  });
});