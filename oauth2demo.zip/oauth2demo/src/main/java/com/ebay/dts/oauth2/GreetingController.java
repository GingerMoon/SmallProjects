package com.ebay.dts.oauth2;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicNameValuePair;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class GreetingController {

    private String refresh_token;

    public static Map<String, String> xhr = new HashMap<String, String>();
    {
        // authorization: Base64 encode the following: <client_id>:<client_secret>
        // https://www.base64decode.org/

        // sandbox
        xhr.put("url", "https://api.sandbox.ebay.com/identity/v1/oauth2/token");
        xhr.put("method", "POST");
        xhr.put("contentType", "application/x-www-form-urlencoded");
        xhr.put("authorization", "Basic bW9vbndhbmctdGVzdC1TQlgtNDI0NmFiMDc1LThmODFmYTIyOlNCWC0yNDZhYjA3NWQ0MTUtYjViMC00MjE2LTkyNzEtNWM2NA====");
        xhr.put("RuName", "moon_wang-moonwang-test-S-ogaenaxyy");

        // production
//        xhr.put("url", "https://api.ebay.com/identity/v1/oauth2/token");
//        xhr.put("method", "POST");
//        xhr.put("contentType", "application/x-www-form-urlencoded");
//        xhr.put("authorization", "Basic bW9vbndhbmctdGVzdC1QUkQtZDI0NjZhZDQ0LTdiYTI5N2E5OlBSRC0yNDY2YWQ0NDM3MjItYzQ4NC00MDQ2LWIxN2QtYTc0Ng==");
//        xhr.put("RuName", "moon_wang-moonwang-test-P-einnyg");
    }

    private HttpPost generatePost() {
        HttpPost post = new HttpPost(xhr.get("url"));
        post.setHeader("Content-Type", xhr.get("contentType"));
        post.setHeader("Authorization", xhr.get("authorization"));
        return post;
    }

    @RequestMapping("/refreshToken")
    public String refreshToken() throws IOException {

        HttpClient client = HttpClientBuilder.create().build();
        HttpPost post = generatePost();
        List<NameValuePair> urlParameters = new ArrayList<NameValuePair>();
        urlParameters.add(new BasicNameValuePair("grant_type", "refresh_token"));
        urlParameters.add(new BasicNameValuePair("refresh_token", refresh_token));
        post.setEntity(new UrlEncodedFormEntity(urlParameters));

        HttpResponse tokenHttpResponse = client.execute(post);
        System.out.println("Response Code : "
                + tokenHttpResponse.getStatusLine().getStatusCode());

        BufferedReader rd = new BufferedReader(
                new InputStreamReader(tokenHttpResponse.getEntity().getContent()));

        StringBuilder tokenSbResponse = new StringBuilder();
        String line = "";
        while ((line = rd.readLine()) != null) {
            tokenSbResponse.append(line);
        }

        JsonParser parse = new JsonParser();
        JsonObject json=(JsonObject) parse.parse(tokenSbResponse.toString());
        String access_token=json.get("access_token").getAsString();
        String token_type=json.get("token_type").getAsString();
        String expires_in=json.get("expires_in").getAsString();

        StringBuilder result = new StringBuilder();
        result.append("<!doctype html><html><head><title>Get eBay Token</title></head><body><div><a href='https://signin.sandbox.ebay.com/authorize?client_id=moonwang-test-SBX-4246ab075-8f81fa22&redirect_uri=moon_wang-moonwang-test-S-ogaenaxyy&response_type=code&state=clientSuppliedStateValue&scope=https%3A%2F%2Fapi.ebay.com%2Foauth%2Fapi_scope%2Fsell.account%20https%3A%2F%2Fapi.ebay.com%2Foauth%2Fapi_scope%2Fsell.inventory'>Get eBay token</a></div><div><a href='/refreshToken'>Refresh eBay token</a></div>Token: ").append(access_token).append("</body></html>");

        return result.toString();
    }


    @RequestMapping("/acceptURL")
    public String acceptURL(@RequestParam(value="state") String state, @RequestParam(value="code") String code) throws IOException {

        HttpClient client = HttpClientBuilder.create().build();
        HttpPost post = generatePost();
        List<NameValuePair> urlParameters = new ArrayList<NameValuePair>();
        urlParameters.add(new BasicNameValuePair("grant_type", "authorization_code"));
        urlParameters.add(new BasicNameValuePair("redirect_uri", "moon_wang-moonwang-test-S-ogaenaxyy"));
        urlParameters.add(new BasicNameValuePair("code", code));
        post.setEntity(new UrlEncodedFormEntity(urlParameters));

        HttpResponse tokenHttpResponse = client.execute(post);
        System.out.println("Response Code : "
                + tokenHttpResponse.getStatusLine().getStatusCode());

        BufferedReader rd = new BufferedReader(
                new InputStreamReader(tokenHttpResponse.getEntity().getContent()));

        StringBuilder tokenSbResponse = new StringBuilder();
        String line = "";
        while ((line = rd.readLine()) != null) {
            tokenSbResponse.append(line);
        }

        JsonParser parse = new JsonParser();
        JsonObject json=(JsonObject) parse.parse(tokenSbResponse.toString());
        String access_token=json.get("access_token").getAsString();
        refresh_token=json.get("refresh_token").getAsString();
        String token_type=json.get("token_type").getAsString();
        String expires_in=json.get("expires_in").getAsString();

        StringBuilder result = new StringBuilder();
        result.append("<!doctype html><html><head><title>Get eBay Token</title></head><body><div><a href='https://signin.sandbox.ebay.com/authorize?client_id=moonwang-test-SBX-4246ab075-8f81fa22&redirect_uri=moon_wang-moonwang-test-S-ogaenaxyy&response_type=code&state=clientSuppliedStateValue&scope=https%3A%2F%2Fapi.ebay.com%2Foauth%2Fapi_scope%2Fsell.account%20https%3A%2F%2Fapi.ebay.com%2Foauth%2Fapi_scope%2Fsell.inventory'>Get eBay token</a></div><div><a href='/refreshToken'>Refresh eBay token</a></div>Token: ").append(access_token).append("</body></html>");

        return result.toString();
    }
}