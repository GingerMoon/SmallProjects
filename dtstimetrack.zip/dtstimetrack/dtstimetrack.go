package main

import (
	"fmt"
	"dtstimetrack/ticket"
	"bufio"
	"os"
	"strings"
	"net/http"
	"io/ioutil"
	"bytes"
)

func main() {
	fmt.Println(` Please input ticket types substring (seperated by blanks) which you want to exclude:
	Examples:
	inputting "suppo" will exclude all the types containing "suppo"
	inputting "meeting consult" will exclude the Training_OR_Meetings and Consulting_OR_Project.
	inputting nothing ('\n') will exclude nothing.

	*********************
	"Meetings":"Training_OR_Meetings",
	"Forum Support":"Forum",
	"Premium Support":"Premium_Support",
	"APIDTS Jira Tickets":"APIDTS_Jira",
	"Support For Emails (Internal/External)	labels":"Email_Support",
	"Engineering Work":"Engineering",
	"Consulting and Project Work":"Consulting_OR_Project",
	*********************
`)

	reader := bufio.NewReader(os.Stdin)
	text, _ := reader.ReadString('\n')
	text = strings.TrimSuffix(text, "\n")
	if len(text) != 0 {
		exclusion := strings.Split(text, " ")
		for k, v := range ticket.Type {
			for _, str := range exclusion {
				if strings.Contains(strings.ToUpper(v), strings.ToUpper(str)) {
					delete(ticket.Type, k)
				}
			}
		}
	}

	url := "https://jirap.corp.ebay.com/rest/api/2/issue"
	for _, v := range ticket.Type {
		ticket.GetBody(v)
		jsonStr := ticket.GetBody(v)

		req, err := http.NewRequest("POST", url, bytes.NewBuffer(jsonStr))
		req.Header.Set("authorization", "Basic eHdhbmcyNDpjb21wYW55QHBmdTE=")
		req.Header.Set("Content-Type", "application/json")

		client := &http.Client{}
		resp, err := client.Do(req)
		if err != nil {
			panic(err)
		}
		defer resp.Body.Close()

		fmt.Println("response Status:", resp.Status)
		fmt.Println("response Headers:", resp.Header)
		body, _ := ioutil.ReadAll(resp.Body)
		fmt.Println("response Body:", string(body))
	}
}
