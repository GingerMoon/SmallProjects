function ghost(isDeactivated) {
  options.style.color = isDeactivated ? 'graytext' : 'black';
  options.frequency.disabled = isDeactivated;
}

var port = chrome.runtime.connect({name: "email"});
function sendEmail() {
	localStorage.mailto = options.mailto.value;
	port.postMessage({action: "SendEmail"});
}
function getContent() {
	port.postMessage({action: "GetContent"});
}

window.addEventListener('load', function() {
  options.mailto.value = localStorage.mailto;
  options.isActivated.checked = JSON.parse(localStorage.isActivated);
  options.frequency.value = localStorage.frequency;
  options.deadline_time.value = localStorage.deadline_time;
  options.deadline_date.value = localStorage.deadline_date;

  if (!options.isActivated.checked) { ghost(true); }

  options.isActivated.onchange = function() {
    localStorage.isActivated = options.isActivated.checked;
    ghost(!options.isActivated.checked);
  };

  options.frequency.onchange = function() {
    localStorage.frequency = options.frequency.value;
  };
  
  options.deadline_date.onchange = function() {
    localStorage.deadline_date = options.deadline_date.value;
  };
    
  options.deadline_time.onchange = function() {
    localStorage.deadline_time = options.deadline_time.value;
  };
  
  options.sendEmail.onclick = sendEmail;
  options.getContent.onclick = getContent;
});