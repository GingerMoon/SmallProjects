package ticket

import (
	"time"
	"fmt"
	"io/ioutil"
	"encoding/json"
	"encoding/base64"
)

/*
Meetings	labels=Training_OR_Meetings
Forum Support	labels=Forum
Premium Support	labels=Premium_Support
APIDTS Jira Tickets	labels=APIDTS_Jira
Support For Emails (Internal/External)	labels = Email_Support
Engineering Work	labels=Engineering
Consulting and Project Work	labels= Consulting_OR_Project

{
    "fields": {
        "assignee": {
            "name": "xwang24"
        },
        "issuetype": {
            "id": "3"
        },
        "timetracking": {
            "remainingEstimate": "5d"
        },
        "project": {
            "id": "29400"
        },
        "labels": [
            "Forum"
        ],
        "description": "CRM Support",
        "summary": "CRM Support",
        "customfield_22616": "2018-03-01",
        "customfield_22617": "2018-03-07"
    }
}
*/

var jsonBegin1 string = `
{
    "fields": {
        "assignee": {
            "name": "`

var jsonBegin2 string = `"
        },
        "issuetype": {
            "id": "3"
        },
        "timetracking": {
            "remainingEstimate": "5d"
        },
        "project": {
            "id": "29400"
        },
		"labels": ["`

var jsonEnd string = `"}}`

var Type = map[string]string {
	"Meetings":"Training_OR_Meetings",
	"Forum Support":"Forum",
	"Premium Support":"Premium_Support",
	"APIDTS Jira Tickets":"APIDTS_Jira",
	"Support For Emails (Internal/External)	labels":"Email_Support",
	"Engineering Work":"Engineering",
	"Consulting and Project Work":"Consulting_OR_Project",
}

var auth struct {
	UserName string
	Password string
}

func init() {
	authorization, err := ioutil.ReadFile("auth.txt")
	if err != nil {
		fmt.Println("Please make sure the username:pwds is maintained in auth.txt")
		fmt.Println(err)
		var input string
		fmt.Scanln(&input)
		panic(err)
	}
	err = json.Unmarshal(authorization, &auth)
	if err!=nil {
		fmt.Println("The content of auth.txt is incorrect.")
		panic(err)
	}
}

func GetAuth() string {
	return "Basic "+ base64.StdEncoding.EncodeToString([]byte(auth.UserName + ":" + auth.Password))
}

func getStartTime() (from time.Time) {
	today := time.Now()
	delta := time.Thursday - today.Weekday()
	if delta > 0 {
		from = today.AddDate(0, 0, int(delta)-7)
	} else {
		from = today.AddDate(0, 0, int(delta))
	}
	return
}

func GetBody(ticket_type string) []byte{

	startTime := getStartTime()
	body := jsonBegin1 + auth.UserName + jsonBegin2 + ticket_type + `"],"description": "` + ticket_type + `","summary": "` + ticket_type +
		`", "customfield_22616":"`  + startTime.Format("2006-01-02") + `","customfield_22617":"` + startTime.AddDate(0,0,6).Format("2006-01-02") + jsonEnd
	fmt.Println(body)
	return []byte(body)
}